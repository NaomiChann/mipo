import cv2
import matplotlib.pyplot as plt
import numpy as np
from skimage.metrics import structural_similarity as ssim

def extract_border( image ):
    # saturated range (gets only places with color)
    min = np.array( [0,  170, 50], np.uint8 )
    max = np.array( [255, 255, 255], np.uint8 )

    # extract saturated areas
    hsv  = cv2.cvtColor( image, cv2.COLOR_BGR2HSV )
    mask = cv2.inRange( hsv, min, max )

    # tries to clean up artifacts a bit
    mask = cv2.morphologyEx( mask, cv2.MORPH_OPEN, kernel )

    return mask

def extract_white( image ):
    gray = cv2.cvtColor( image, cv2.COLOR_BGR2GRAY )

    # extract bright areas
    _, thresh = cv2.threshold( gray, 150, 255, cv2.THRESH_BINARY )

    # tries to clean up artifacts a bit
    open = cv2.morphologyEx( thresh, cv2.MORPH_CLOSE, kernel )
    open = cv2.morphologyEx( open, cv2.MORPH_OPEN, kernel )

    return open

def process_image( input, visualize = False ):
    border = extract_border( input )
    filling = extract_white( input )
    combined = border + filling
    combined = cv2.morphologyEx( combined, cv2.MORPH_CLOSE, kernel )

    if visualize:
        _, ax = plt.subplots( 1, 3 )

        ax[0].imshow( border, cmap = "gray" )
        ax[0].set_title( "border" )
        ax[1].imshow( filling, cmap = "gray" )
        ax[1].set_title( "filling" )
        ax[2].imshow( combined, cmap = "gray" )
        ax[2].set_title( "combined" )

        plt.show()

    return border, filling, combined

def crop_contoured_area( image ):
    contours, _ = cv2.findContours( image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )

    for contour in contours:
        x, y, w, h = cv2.boundingRect( contour )
        cropped_area = image[y:y + h, x:x + w]

    # ignores small areas if any left still
        if cropped_area.size > image.size / 4:
            return cropped_area
        
def score_img( im1, im2 ):
    score, diff = ssim( im1, im2, full = True )

    diff = ( diff * 255 ).astype( "uint8" )

    return diff, score

def compare( input1, input2, visualizer = False ):
    border1, _, combined1 = process_image( input1 )
    border2, _, combined2 = process_image( input2 )

    c_border1 = crop_contoured_area( border1 )
    c_border2 = crop_contoured_area( border2 )
    c_combined1 = crop_contoured_area( combined1 )
    c_combined2 = crop_contoured_area( combined2 )

    try:
        c_border1 = cv2.resize( c_border1, ( 250, 250 ) )

        c_border2 = cv2.resize( c_border2, ( 250, 250 ) )

        c_combined1 = cv2.resize( c_combined1, ( 250, 250 ) )
            
        c_combined2 = cv2.resize( c_combined2, ( 250, 250 ) )
    except Exception as e:
        return False, None


    subbed1 = c_combined1 - c_border1
    subbed2 = c_combined2 - c_border2

    b_diff, score1 = score_img( c_border1, c_border2 )
    s_diff, score2 = score_img( subbed1, subbed2 )

    if visualizer:
        _, ax = plt.subplots( 2, 2 )

        ax[0][0].imshow( c_border1, cmap = "gray" )
        ax[0][1].imshow( subbed1, cmap = "gray" )
        ax[1][0].imshow( c_border2, cmap = "gray" )
        ax[1][1].imshow( subbed2, cmap = "gray" )

        plt.show()

        _, ax = plt.subplots( 1, 2 )

        ax[0].imshow( b_diff, cmap = "gray" )
        ax[1].imshow( s_diff, cmap = "gray" )

        plt.show()

    print( score1, score2 )

    if score1 > 0.8 and score2 > 0.8:
        contours, _ = cv2.findContours( combined1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )
        return True, contours
    else:
        return False, None

def detection( input1, visualize = False ):
    for s in signs:
        input2 = cv2.imread( s )
        result, contours = compare( input1, input2, visualize )
        if result:
            for i, _ in enumerate( contours ):
                cv2.drawContours( input1, contours, i, color, thickness )

            cv2.putText( input1, signs[s], org, font, font_scale, color, thickness, cv2.LINE_AA )
            break
    return input1

def get_cam():
    cap = cv2.VideoCapture( 0, cv2.CAP_V4L2 )
    cap.set( cv2.CAP_PROP_FPS, 1 )

    while cap.isOpened():
        _, frame = cap.read()

        input1 = detection( frame )
        cv2.imshow( "Treated?", input1 )

        if cv2.waitKey( 1 ) & 0xFF == ord( "q" ):
            break

    cap.release()
    cv2.destroyAllWindows()

def debug_cam( t1 = False, t2 = False ):
    cap = cv2.VideoCapture( 0, cv2.CAP_V4L2 )
    cap.set( cv2.CAP_PROP_FPS, 1 )

    while cap.isOpened():
        _, frame = cap.read()
        input2 = cv2.imread( "signs13.png" )

        if t1:
            border1, _,combined1 = process_image( frame )
            c_border1 = crop_contoured_area( border1 )
            c_combined1 = crop_contoured_area( combined1 )

            try:
                c_border1 = cv2.resize( c_border1, ( 250, 250 ) )
                c_combined1 = cv2.resize( c_combined1, ( 250, 250 ) )

                cv2.imshow( "b", c_border1 )
                cv2.imshow( "c", c_combined1 )

                contours, _ = cv2.findContours( combined1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE )
                for i, _ in enumerate( contours ):
                    cv2.drawContours( frame, contours, i, color, thickness )
            except Exception as e:
                continue

        if t2:
            try:
                _, contours = compare( frame, input2 )
                if contours != None:
                    for i, _ in enumerate( contours ):
                        cv2.drawContours( frame, contours, i, color, thickness )
            except Exception as e:
                continue

        cv2.imshow( "hi", frame )

        if cv2.waitKey( 1 ) & 0xFF == ord( "q" ):
            break

    cap.release()
    cv2.destroyAllWindows()

###########################################################
        
###########################################################

# font setup
font = cv2.FONT_HERSHEY_SIMPLEX
org = ( 5, 20 )
font_scale = 0.6
color = ( 0, 255, 0 )
thickness = 2

# bigger kernel = less artifacts in general
kernel = np.ones( ( 7, 7 ), np.uint8 )

signs = {
    "signs1.png": "Parada obrigatoria",
    "signs2.png": "De a preferencia",
    "signs3.png": "Velocidade maxima",
    "signs4.png": "Sentido de circulacao",
    "signs5.png": "Passagem obrigatoria",
    "signs6.png": "Siga em frente",
    "signs7.png": "Vire a esquerda",
    "signs8.png": "Vire a direita",
    "signs9.png": "Siga em frente ou a esquerda",
    "signs10.png": "Siga em frente ou a direita",
    "signs11.png": "Sentido proibido",
    "signs12.png": "Proibido virar a esquerda",
    "signs13.png": "Proibido virar a direita",
    "signs14.png": "Proibido retornar a esquerda",
    "signs15.png": "Proibido mudar de faixa para a direita"
}

###########################################################
        
###########################################################

# source = "in1.png"
# input1 = cv2.imread( source )

# cv2.imshow( "out", detection( input1 ) )

get_cam()
# debug_cam( t2 = True )